package com.ustadh.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (BuildConfig.APP_URL.equals("https://example.com")) {
            showSetupMessage();
            return;
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the deployed app in this WebView. External links can be handled later.
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl(BuildConfig.APP_URL);
    }

    private void showSetupMessage() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.rgb(248, 250, 252));

        TextView title = new TextView(this);
        title.setText("الأستاذ");
        title.setTextSize(32);
        title.setTextColor(Color.rgb(18, 90, 70));
        title.setGravity(Gravity.CENTER);

        TextView message = new TextView(this);
        message.setText("مدرّسك الذكي\n\nتم تجهيز هيكل التطبيق. بقي ربطه بعنوان الخادم الآمن (HTTPS) وتجهيز تسجيل الدخول قبل بناء النسخة النهائية.");
        message.setTextSize(18);
        message.setTextColor(Color.DKGRAY);
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, 24, 0, 0);

        layout.addView(title);
        layout.addView(message);
        setContentView(layout);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
